'use strict';
const MODES=require('./modes'),PVE=require('./pve'),{calc,baseStats,defs}=require('./data');
const clamp=(v,a,b)=>v<a?a:v>b?b:v,num=(v,d=0)=>Number.isFinite(+v)?+v:d,r2=v=>Math.round(v*100)/100,PI=Math.PI,TAU=PI*2;
const adf=(a,b)=>{let d=(b-a)%TAU;if(d>PI)d-=TAU;if(d<-PI)d+=TAU;return d};
const BOTN=['Rufus','Maximus','Cassius','Brutus','Titus','Nero','Spartak','Crixus','Varro','Lucan','Flavius','Gaius'];
class Room{
  constructor(id,name,modeId,bots,owner){
    this.id=id;this.name=name;this.modeId=modeId;this.mode=MODES[modeId];this.players=new Map();this.nid=1;this.phase='play';this.t=this.mode.roundTime||0;this.endAt=0;this.winner='';
    this.botTarget=this.mode.pve?0:clamp(bots|0,0,8);this.owner=owner;this.tk=0;this.emptySince=0;this.max=16;this.bn=0;
    if(this.mode.init)this.mode.init(this)}
  humans(){return[...this.players.values()].filter(p=>!p.bot)}
  bc(o,except){const s=JSON.stringify(o);for(const p of this.players.values())if(!p.bot&&p.ws!==except&&p.ws.readyState===1)p.ws.send(s)}
  send(p,o){if(!p.bot&&p.ws.readyState===1)p.ws.send(JSON.stringify(o))}
  pub(p){return{id:p.id,name:p.name,team:p.team,bot:p.bot?1:0,x:r2(p.x),z:r2(p.z),hp:Math.round(p.hp),dead:p.dead}}
  mkPlayer(name,ws,bot){return{id:this.nid++,ws,name,bot:!!bot,team:0,x:0,y:0,z:0,yaw:0,pitch:0,vx:0,vz:0,sw:-1,swt:0,blk:0,roll:0,use:0,hp:100,dead:false,deaths:0,kills:0,score:0,blkSince:0,gbUntil:0,stunUntil:0,bst:100,spawnProt:0,respawnAt:0,lastHit:{},sk:{},pk:[],sp:0,draft:[],picked:0,ready:0,cdE:0,cdR:0,frenzy:0,ironUsed:0,S:baseStats(),ai:{}}}
  assignTeam(p){if(!this.mode.teams)return;const c=[0,0];for(const q of this.players.values())if(q!==p)c[q.team]++;p.team=c[0]<=c[1]?0:1}
  cleanName(raw){let n=String(raw||'').replace(/[\u0000-\u001f<>&"'`]/g,'').trim().slice(0,16)||'Gladyatör';const b=n.slice(0,13),used=new Set([...this.players.values()].map(p=>p.name.toLowerCase()));let i=2;while(used.has(n.toLowerCase()))n=b+' '+i++;return n}
  join(ws,name){
    const p=this.mkPlayer(this.cleanName(name),ws,false);this.assignTeam(p);this.players.set(p.id,p);this.emptySince=0;this.spawn(p,true);
    if(this.mode.onJoin)this.mode.onJoin(this,p);
    this.send(p,{t:'welcome',id:p.id,team:p.team,room:{id:this.id,name:this.name,owner:this.owner===ws},mode:{id:this.modeId,name:this.mode.name,desc:this.mode.desc,teams:this.mode.teams||0,pve:!!this.mode.pve},spawn:{x:r2(p.x),z:r2(p.z)},
      players:[...this.players.values()].filter(q=>q!==p).map(q=>this.pub(q)),tl:Math.ceil(this.t),ph:this.phase,defs:this.mode.pve?defs():null,S:this.mode.pve?p.S:null});
    this.bc({t:'join',p:this.pub(p)},ws);this.sendSB();return p}
  leave(p){this.players.delete(p.id);this.bc({t:'leave',id:p.id});if(!this.humans().length)this.emptySince=Date.now();this.sendSB()}
  addBot(){if(this.players.size>=this.max||this.mode.pve)return;const p=this.mkPlayer('Bot '+BOTN[this.bn++%BOTN.length],{readyState:0},true);this.assignTeam(p);this.players.set(p.id,p);this.spawn(p,true);this.bc({t:'join',p:this.pub(p)});this.sendSB()}
  delBot(){const b=[...this.players.values()].filter(p=>p.bot).pop();if(!b)return;this.players.delete(b.id);this.bc({t:'leave',id:b.id});this.sendSB()}
  spawn(p,silent){const s=this.mode.spawnPoint(this,p);p.x=s.x;p.z=s.z;p.y=0;p.hp=p.S.hp;p.dead=false;p.bst=100;p.spawnProt=Date.now()+2500;p.blk=0;p.gbUntil=0;p.stunUntil=0;p.sw=-1;p.use=0;p.ai={};
    if(!silent)this.bc({t:'spawn',id:p.id,x:r2(p.x),z:r2(p.z),hp:Math.round(p.hp)})}
  onState(p,m){
    if(p.dead)return;let x=clamp(num(m.x),-30,30),z=clamp(num(m.z),-30,30);const r=Math.hypot(x,z);if(r>22){x*=22/r;z*=22/r}
    p.x=x;p.z=z;p.y=clamp(num(m.y),-1,8);p.yaw=num(m.yaw);p.pitch=clamp(num(m.pitch),-1.6,1.6);p.vx=clamp(num(m.vx),-15,15);p.vz=clamp(num(m.vz),-15,15);
    const sw=m.sw|0;p.sw=sw<-1||sw>3?-1:sw;p.swt=clamp(num(m.swt),0,1);
    const now=Date.now();let b=m.blk?1:0;if(now<p.gbUntil)b=0;if(b&&!p.blk)p.blkSince=now;p.blk=b;p.roll=m.roll?1:0;p.use=m.use?1:0}
  canHit(a,v){return this.phase=='play'&&!a.dead&&!v.dead&&Date.now()>=v.spawnProt&&!v.roll&&this.mode.canDamage(this,a,v)}
  onHit(a,m){
    if(a.dead||this.phase!='play')return;
    if(m.e!=null){if(this.mode.pve)PVE.hitEnemy(this,a,m);return}
    if((m.id|0)===-1){if(this.mode.onHitExtra)this.mode.onHitExtra(this,a,m);return}
    const v=this.players.get(m.id|0),now=Date.now();
    if(!v||v===a||now<a.stunUntil||!this.canHit(a,v)||(a.lastHit[v.id]||0)+280>now)return;
    if(Math.hypot(v.x-a.x,v.z-a.z)>5.5)return;a.lastHit[v.id]=now;
    this.strike(a,v,clamp(num(m.sp),0,40),!!m.hv,!!m.head,clamp(num(m.x),-30,30),clamp(num(m.y),0,4),clamp(num(m.z),-30,30))}
  strike(a,v,sp,hv,head,hx,hy,hz){
    const now=Date.now(),dx=v.x-a.x,dz=v.z-a.z,d=Math.hypot(dx,dz)||.001;
    let dmg=Math.min(75,22*a.S.dmg*(hv?2.2:1)*clamp(sp/12,.55,1.6)*(head?1.5:1)),bl=0,pr=0,gb=0;
    const front=(-Math.sin(v.yaw))*(-dx/d)+(-Math.cos(v.yaw))*(-dz/d)>.3;
    if(v.blk&&front){
      if(now-v.blkSince<v.S.parry*1000+120){pr=1;dmg=0;a.stunUntil=now+900;v.hp=Math.min(v.S.hp,v.hp+v.S.parryHeal)}
      else{bl=1;v.bst-=dmg*.8*v.S.blkCost;dmg*=hv?.45:1-v.S.blk;if(v.bst<=0||hv&&v.bst<20){v.bst=0;v.gbUntil=now+1200;v.blk=0;gb=1}}}
    v.hp-=dmg;
    this.bc({t:'dmg',to:v.id,from:a.id,dmg:Math.round(dmg),hp:Math.max(0,Math.round(v.hp)),bl,pr,gb,kx:r2(dx/d),kz:r2(dz/d),kn:1,x:r2(hx),y:r2(hy),z:r2(hz)});
    if(v.hp<=0)this.kill(a,v,head)}
  hurtPlayer(p,dmg,sx,sz,src,kind){
    const now=Date.now();if(p.dead||now<p.spawnProt||p.roll||this.phase!='play')return;
    const dx=sx-p.x,dz=sz-p.z,dd=Math.hypot(dx,dz)||1,front=(-Math.sin(p.yaw))*(dx/dd)+(-Math.cos(p.yaw))*(dz/dd)>.3,S=p.S;let bl=0,pr=0,gb=0;
    if(p.blk&&front&&kind!='s'){
      if(now-p.blkSince<S.parry*1000+120&&src){pr=1;dmg=0;PVE.stag(src,1.2);p.hp=Math.min(S.hp,p.hp+S.parryHeal)}
      else{bl=1;p.bst-=dmg*.8*S.blkCost;dmg*=1-S.blk;if(p.bst<=0){p.bst=0;p.gbUntil=now+1200;p.blk=0;gb=1}}}
    if(dmg>0){if(S.iron&&!p.ironUsed&&p.hp-dmg<=0){p.hp=S.hp*.3;p.ironUsed=1;p.spawnProt=now+1000}else p.hp-=dmg;if(src&&S.thorn)PVE.thorn(this,src,p,S.thorn)}
    this.bc({t:'dmg',to:p.id,from:-1,dmg:Math.round(dmg),hp:Math.max(0,Math.round(p.hp)),bl,pr,gb,kx:r2(-dx/dd),kz:r2(-dz/dd),kn:kind=='c'?3.3:1,x:r2(p.x),y:1.2,z:r2(p.z)});
    if(p.hp<=0)this.down(p,src)}
  respawnDelay(p){return this.mode.respawnFor?this.mode.respawnFor(this,p):(this.mode.respawnMs||4000)}
  down(p,src){p.dead=true;p.hp=0;p.deaths++;p.respawnAt=Date.now()+this.respawnDelay(p);this.bc({t:'kill',killer:-1,victim:p.id,kn:src&&src.df?src.df.n:'Düşman',vn:p.name,head:0,respawn:this.respawnDelay(p)});this.sendSB()}
  kill(a,v,head){
    v.dead=true;v.hp=0;v.deaths++;a.kills++;v.respawnAt=Date.now()+this.respawnDelay(v);if(this.mode.onKill)this.mode.onKill(this,a,v);
    this.bc({t:'kill',killer:a.id,victim:v.id,kn:a.name,vn:v.name,head:head?1:0,respawn:this.respawnDelay(v)});this.sendSB();
    if(this.mode.isOver(this))this.endRound('score')}
  endRound(reason){
    if(this.phase!='play')return;this.phase='end';
    const l=[...this.players.values()].sort((a,b)=>this.mode.scoreOf(b)-this.mode.scoreOf(a)||a.deaths-b.deaths);
    this.winner=this.mode.winner?this.mode.winner(this,reason):(l.length?l[0].name:'-');if(this.mode.onRoundEnd)this.mode.onRoundEnd(this,reason);
    this.endAt=Date.now()+8000;this.bc({t:'round',ph:'end',w:this.winner});this.sendSB()}
  newRound(){
    this.phase='play';this.t=this.mode.roundTime||0;this.winner='';if(this.mode.reset)this.mode.reset(this);
    for(const p of this.players.values()){p.deaths=0;this.spawn(p)}
    this.bc({t:'round',ph:'play'});this.sendSB()}
  sendSB(){
    const l=[...this.players.values()].sort((a,b)=>this.mode.scoreOf(b)-this.mode.scoreOf(a)||a.deaths-b.deaths).map(p=>[p.id,p.name,this.mode.scoreOf(p),p.deaths,p.team,p.bot?1:0]);
    this.bc({t:'sb',l,tl:Math.ceil(this.t),ph:this.phase,w:this.winner,info:this.mode.info?this.mode.info(this):'',x:this.mode.sbExtra?this.mode.sbExtra(this):null})}
  tick(){
    const now=Date.now(),dt=.05;this.tk++;
    if(!this.mode.pve){const nb=[...this.players.values()].filter(p=>p.bot).length;if(nb<this.botTarget&&this.tk%10==0)this.addBot();else if(nb>this.botTarget)this.delBot()}
    for(const p of this.players.values()){
      if(p.dead&&this.phase=='play'&&now>=p.respawnAt)this.spawn(p);
      if(!p.dead&&p.bst<100)p.bst=Math.min(100,p.bst+15*dt);
      if(p.bot&&!p.dead&&this.phase=='play')stepBot(this,p,dt)}
    if(this.phase=='play'&&this.mode.roundTime){this.t-=dt;if(this.t<=0)this.endRound('time')}
    else if(this.phase=='end'&&now>=this.endAt)this.newRound();
    if(this.mode.onTick)this.mode.onTick(this,dt);
    if(this.phase=='play'&&this.mode.isOver&&this.mode.isOver(this))this.endRound('score');
    if(this.players.size){const ex=this.mode.snapExtra?this.mode.snapExtra(this):{};
      this.bc(Object.assign({t:'snap',p:[...this.players.values()].map(p=>[p.id,r2(p.x),r2(p.y),r2(p.z),r2(p.yaw),r2(p.pitch),r2(p.vx),r2(p.vz),p.sw,r2(p.swt),p.blk,Math.round(p.hp),p.dead?1:0])},ex))}
    if(this.tk%20==0)this.sendSB()}
}
function stepBot(r,b,dt){
  const now=Date.now(),ai=b.ai;
  if(now<b.stunUntil){b.vx=b.vz=0;b.sw=-1;return}
  let tg=null,bd=1e9;for(const q of r.players.values()){if(q===b||q.dead||!r.mode.canDamage(r,b,q))continue;const d=(q.x-b.x)**2+(q.z-b.z)**2;if(d<bd){bd=d;tg=q}}
  const goal=r.mode.botGoal?r.mode.botGoal(r,b):null;let tx,tz,keep;
  if(tg&&(bd<324||!goal)){tx=tg.x;tz=tg.z;keep=2.3}else if(goal){tx=goal.x;tz=goal.z;keep=goal.keep||1.2}else{tx=0;tz=0;keep=6}
  const dx=tx-b.x,dz=tz-b.z,d=Math.hypot(dx,dz)||.01;b.yaw+=adf(b.yaw,Math.atan2(-dx,-dz))*Math.min(1,dt*8);
  let vx=0,vz=0;const sp=3.7;
  if(!(b.sw>=0)){if(d>keep+.3){vx=dx/d*sp;vz=dz/d*sp}else if(d<keep-.7&&tg===null){}else if(d<keep-.7){vx=-dx/d*sp*.6;vz=-dz/d*sp*.6}
    if(tg&&d<6){if((ai.sideT=(ai.sideT||0)-dt)<=0){ai.side=Math.random()<.5?-1:1;ai.sideT=1+Math.random()*2}const s=ai.side||1;vx+=-dz/d*s*sp*.5;vz+=dx/d*s*sp*.5}}
  b.vx=vx;b.vz=vz;b.x+=vx*dt;b.z+=vz*dt;const rr=Math.hypot(b.x,b.z);if(rr>21){b.x*=21/rr;b.z*=21/rr}
  if(b.sw>=0){b.swt+=dt/.5;
    if(b.swt>=.3&&b.swt<=.66&&!ai.hit&&tg&&Math.hypot(tg.x-b.x,tg.z-b.z)<2.9&&r.canHit(b,tg)){ai.hit=1;r.strike(b,tg,10+Math.random()*5,false,Math.random()<.08,tg.x,1.2,tg.z)}
    if(b.swt>=1){b.sw=-1;b.swt=0;ai.cd=now+350+Math.random()*700}}
  else if(tg&&bd<2.8*2.8&&now>=(ai.cd||0)){ai.combo=((ai.combo||0)+1)%3;b.sw=ai.combo;b.swt=0;ai.hit=0}
  if(b.blk&&now>=(ai.bu||0))b.blk=0;
  else if(!b.blk&&b.sw<0&&tg&&tg.sw>=0&&bd<3.5*3.5&&Math.random()<.05){b.blk=1;b.blkSince=now;ai.bu=now+700}
  b.use=goal&&goal.use&&d<2.4?1:0}
module.exports={Room};

'use strict';
/* PvE: 10 Gün Seferi (co-op) — düşman yapay zekası sunucuda çalışır */
const {ED,calc,SKILLS,PERKS}=require('./data');
const clamp=(v,a,b)=>v<a?a:v>b?b:v,num=(v,d=0)=>Number.isFinite(+v)?+v:d,R=Math.random,PI=Math.PI,TAU=PI*2,WALL=21.3,r2=v=>Math.round(v*100)/100;
const adf=(a,b)=>{let d=(b-a)%TAU;if(d>PI)d-=TAU;if(d<-PI)d+=TAU;return d};
const DAYN=['Kum Çıraklığı','İlk Kan','Trakyalı Gölgeler','Mızrak Yağmuru','Halkın Sesi','Demir Eller','Kızıl Hafta','Ölüm Kumu','Şampiyonların Eşiği','FİNAL: Arena Lordu'];
const ST=['move','wind','rec','stag','charge'];
const humans=r=>[...r.players.values()].filter(p=>!p.bot),alive=r=>[...r.players.values()].filter(p=>!p.dead);
function init(r){r.day=1;r.en=[];r.pj=[];r.eid=1;r.D={phase:'idle'};r.hs=1}
function reset(r){r.day=1;for(const p of r.players.values()){p.sk={};p.pk=[];p.sp=0;p.draft=[];p.picked=0;p.ironUsed=0;p.S=calc({},[]);p.kills=0;sendProg(r,p)}startDay(r)}
function onJoin(r,p){p.sp=2*(r.day-1);p.S=calc(p.sk,p.pk);p.hp=p.S.hp;sendProg(r,p);if(r.D.phase=='camp'){r.send(p,{t:'camp',sec:Math.ceil(r.D.campLeft),day:r.day});}}
function startDay(r){
  const n=Math.max(1,humans(r).length),d=r.day,boss=d==10;r.en=[];r.pj=[];r.hs=1+.55*(n-1);
  r.D={phase:'fight',total:(boss?6:[3,4,5,6,7,8,9,10,12][d-1])+(n-1)*2,spawned:0,t:2,max:Math.min(3+(d>>1),7)+(n-1)*2,boss,bs:0,fin:0,t2:0,bossDead:0,fail:0,campLeft:0};
  for(const p of r.players.values()){p.ready=0;p.ironUsed=0;r.spawn(p)}
  r.bc({t:'day',day:d,name:DAYN[d-1],phase:'fight'})}
function pickType(d){const r=R();if(d>=6&&r<.2)return'brute';if(d>=4&&r<.4)return'thrower';if(d>=2&&r<.65)return'fast';return'grunt'}
function spawnE(r,type,gate){
  const df=ED[type],a=gate*PI/2,rr=WALL-1.3,boss=df.boss,id=r.eid++;
  const E={id,type,df,x:Math.sin(a)*rr,z:Math.cos(a)*rr,yaw:a+PI,hp:df.hp*(boss?1+.8*(r.hs-1)/.55*.55:(1+.1*(r.day-1))*r.hs),dmg:df.dmg*(1+.07*(r.day-1)),sc:df.sc,rad:Math.max(.4,df.rad*df.sc*.9),h:1.85,spd:df.spd*(1+.02*r.day),mv:df.mv,
    state:'move',t0:0,cd:1.2+R()*1.5,cur:null,mi:0,kx:0,kz:0,side:R()<.5?-1:1,sideT:2,stag:0,bleed:0,bleedD:0,big:df.big,boss,dead:0,dbl:0,sum:boss?2:0,hitC:0,cdx:0,cdz:0,mvs:0,by:null};
  E.max=E.hp;r.en.push(E);r.bc({t:'es',id,type,x:r2(E.x),z:r2(E.z)});return E}
function stag(E,t){if(E.boss&&E.state!='charge')return;E.state='stag';E.stag=t;E.t0=0;E.cur=null}
function melee(r,E,mv){E.kx+=Math.sin(E.yaw)*3;E.kz+=Math.cos(E.yaw)*3;
  for(const q of alive(r))if(Math.hypot(q.x-E.x,q.z-E.z)<mv.reach*E.sc*.8+.5&&Math.abs(adf(E.yaw,Math.atan2(q.x-E.x,q.z-E.z)))<1.1)r.hurtPlayer(q,E.dmg*mv.dm,E.x,E.z,E,'m')}
function strike(r,E,P,face){
  const mv=E.cur;
  if(mv.k=='m'){melee(r,E,mv);if(mv.dbl)E.dbl=.22}
  else if(mv.k=='s'){const ax=E.x+Math.sin(E.yaw)*2.4*E.sc,az=E.z+Math.cos(E.yaw)*2.4*E.sc;r.bc({t:'fx',k:'slam',x:r2(ax),z:r2(az),r:mv.R});
    for(const q of alive(r))if(Math.hypot(q.x-ax,q.z-az)<mv.R&&q.y<.7)r.hurtPlayer(q,E.dmg*mv.dm,ax,az,E,'s')}
  else if(mv.k=='t'){const tx=P.x+P.vx*.25,ty=P.y+1.1,tz=P.z+P.vz*.25,y0=1.6*E.sc,dx=tx-E.x,dz=tz-E.z,d=Math.hypot(dx,dz),T=Math.max(.2,d/17),g=14;
    r.pj.push({id:r.eid++,x:E.x,y:y0,z:E.z,vx:dx/T,vy:(ty-y0+.5*g*T*T)/T,vz:dz/T,dmg:E.dmg,life:6})}
  else if(mv.k=='c'){E.state='charge';E.t0=0;E.cdx=Math.sin(face);E.cdz=Math.cos(face);E.hitC=0;return}
  E.state='rec';E.t0=0}
function stepEnemy(r,E,dt){
  const pl=alive(r);if(!pl.length)return;
  let P=pl[0],bd=1e9;for(const q of pl){const d=(q.x-E.x)**2+(q.z-E.z)**2;if(d<bd){bd=d;P=q}}
  if(E.bleed>0){E.bleed-=dt;E.hp-=E.bleedD*dt;if(E.hp<=0){killE(r,E,E.by,0,0,0,0);return}}
  const dx=P.x-E.x,dz=P.z-E.z,d=Math.hypot(dx,dz)||.01,face=Math.atan2(dx,dz),fx=dx/d,fz=dz/d,A=E.state;
  if(A!='charge')E.yaw+=adf(E.yaw,face)*Math.min(1,dt*(A=='move'?8:A=='wind'?3:1.5));
  let vx=0,vz=0;E.t0+=dt;
  if(E.dbl>0&&(E.dbl-=dt)<=0&&E.cur)melee(r,E,E.cur);
  if(A=='move'){
    E.cd-=dt;if((E.sideT-=dt)<=0){E.side*=-1;E.sideT=1.5+R()*2.5}
    let want=0,side=0;const rc=E.mv[0].reach*E.sc*.8,enr=E.boss&&E.hp<E.max*.33;
    if(E.type=='thrower'){want=d<7?-1:d>12?1:0;side=E.side*.8}else{want=d>rc?1:d<rc*.55?-.5:0;if(d<5&&d>rc)side=E.side*.5}
    const sp=E.spd*(enr?1.3:1);vx=fx*want*sp+fz*side*sp;vz=fz*want*sp-fx*side*sp;
    if(E.cd<=0){const c=[];E.mv.forEach((m,i)=>{if(m.k=='c'?d>5.5:m.k=='t'?(d>5&&d<17):d<m.reach*E.sc*.8+.5)c.push(i)});
      if(c.length){E.mi=c[(R()*c.length)|0];E.cur=E.mv[E.mi];E.state='wind';E.t0=0}else E.cd=.2}}
  else if(A=='wind'){if(E.t0>=E.cur.wd)strike(r,E,P,face)}
  else if(A=='rec'){if(E.t0>=E.cur.rec){E.state='move';E.cd=(.5+R()*1.3)/(E.boss&&E.hp<E.max*.33?1.4:1)}}
  else if(A=='stag'){if(E.t0>=E.stag){E.state='move';E.cd=.4}}
  else if(A=='charge'){vx=E.cdx*15;vz=E.cdz*15;
    if(!E.hitC)for(const q of pl)if(Math.hypot(q.x-E.x,q.z-E.z)<1.6*E.sc){E.hitC=1;r.hurtPlayer(q,E.dmg*E.cur.dm,E.x,E.z,E,'c');break}
    if(Math.hypot(E.x,E.z)>WALL-E.rad-.3){E.state='stag';E.stag=2.2;E.t0=0;r.bc({t:'fx',k:'slam',x:r2(E.x),z:r2(E.z),r:5,c:1})}else if(E.t0>.8){E.state='rec';E.t0=0}}
  if(E.boss&&E.sum>0&&E.hp<E.max*(E.sum==2?.66:.33)){E.sum--;E.state='stag';E.stag=1.4;E.t0=0;for(let i=0;i<3;i++)spawnE(r,'grunt',(R()*4)|0);r.bc({t:'fx',k:'msg',m:'Draco yardımcılarını çağırdı!'})}
  E.x+=(vx+E.kx)*dt;E.z+=(vz+E.kz)*dt;const kd=Math.exp(-6*dt);E.kx*=kd;E.kz*=kd;E.mvs=Math.min(1,Math.hypot(vx,vz)/3)}
function sepEnemies(r){const en=r.en,pl=alive(r);
  for(let i=0;i<en.length;i++){const a=en[i];for(let j=i+1;j<en.length;j++){const b=en[j],dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz)||.01,m=a.rad+b.rad;if(d<m){const o=(m-d)/2/d;a.x-=dx*o;a.z-=dz*o;b.x+=dx*o;b.z+=dz*o}}
    for(const q of pl){const dx=a.x-q.x,dz=a.z-q.z,d=Math.hypot(dx,dz)||.01,m=a.rad+.45;if(d<m&&q.y<1.2){a.x+=dx/d*(m-d)*.7;a.z+=dz/d*(m-d)*.7}}
    const rr=Math.hypot(a.x,a.z);if(rr>WALL-a.rad){a.x*=(WALL-a.rad)/rr;a.z*=(WALL-a.rad)/rr}}}
function stepPj(r,dt){const pl=alive(r);
  for(let i=r.pj.length-1;i>=0;i--){const p=r.pj[i];p.life-=dt;p.vy-=14*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;let rm=p.life<=0||p.y<.05||Math.hypot(p.x,p.z)>WALL+1;
    if(!rm)for(const q of pl)if(Math.hypot(p.x-q.x,p.z-q.z)<.6&&p.y>q.y&&p.y<q.y+1.9){r.hurtPlayer(q,p.dmg,p.x-p.vx,p.z-p.vz,null,'t');rm=true;break}
    if(rm)r.pj.splice(i,1)}}
function killE(r,E,by,kx,kz,hv,head){
  if(E.dead)return;E.dead=1;const i=r.en.indexOf(E);if(i>=0)r.en.splice(i,1);
  r.bc({t:'ed',id:E.id,kx:r2(kx),kz:r2(kz),hv:hv?1:0,head:head?1:0,by:by?by.id:0});
  if(by&&!by.dead){by.kills++;by.score++;by.hp=Math.min(by.S.hp,by.hp+by.S.killHeal);if(by.S.frenzy)by.frenzy=Date.now()+4000}
  if(E.boss)r.D.bossDead=1}
function dmgEnemy(r,p,E,mult,hv,head,sp,hx,hy,hz,aoe){
  const dxp=E.x-p.x,dzp=E.z-p.z,dp=Math.hypot(dxp,dzp)||1,kx=dxp/dp,kz=dzp/dp,S=p.S,now=Date.now();
  if(E.df.shield&&(E.state=='move'||E.state=='rec')&&!hv&&!aoe){E.kx+=kx*1.5;E.kz+=kz*1.5;r.bc({t:'eh',e:E.id,bl:1,x:r2(hx),y:r2(hy),z:r2(hz),kx:r2(kx),kz:r2(kz),by:p.id});return}
  let dmg=22*S.dmg*mult*(p.frenzy>now?1.3:1)*(E.big?S.giant:1)*clamp(sp/12,.55,1.6)*(head?1.5:1);const cr=R()<S.crit;if(cr)dmg*=S.critM;
  E.hp-=dmg;E.by=p;E.kx+=kx*(2+sp*.3)*(hv?1.8:1)/E.sc;E.kz+=kz*(2+sp*.3)*(hv?1.8:1)/E.sc;
  if(S.vamp)p.hp=Math.min(S.hp,p.hp+dmg*S.vamp);if(S.bleed){E.bleed=3;E.bleedD=S.bleed/3}
  if(!E.boss&&(hv||aoe||dmg>E.max*.2||(head&&dmg>E.max*.12)))stag(E,hv?1:.55);else if(!E.boss&&E.state=='wind'&&dmg>E.max*.07)stag(E,.35);
  r.bc({t:'eh',e:E.id,dmg:Math.round(dmg),cr:cr?1:0,x:r2(hx),y:r2(hy),z:r2(hz),kx:r2(kx),kz:r2(kz),by:p.id});
  if(E.hp<=0)killE(r,E,p,kx,kz,hv,head)}
function hitEnemy(r,p,m){
  const E=r.en.find(e=>e.id==(m.e|0));if(!E||E.dead||p.dead||r.D.phase!='fight')return;
  const now=Date.now();if((p.lastHit['e'+E.id]||0)+280>now)return;
  if(Math.hypot(E.x-p.x,E.z-p.z)>5+E.rad)return;p.lastHit['e'+E.id]=now;
  const hv=!!m.hv,sp=clamp(num(m.sp),0,40),ch=clamp(num(m.ch),0,1),cmb=clamp(num(m.cmb),0,8);
  dmgEnemy(r,p,E,hv?p.S.heavy*(1+ch*1.3):1+.06*cmb,hv,!!m.head,sp,clamp(num(m.x),-30,30),clamp(num(m.y),0,4),clamp(num(m.z),-30,30),false)}
function onAbil(r,p,m){
  const now=Date.now(),S=p.S;if(p.dead||r.D.phase!='fight')return;
  if(m.k=='E'&&S.whirl&&now>=p.cdE){p.cdE=now+8500;for(const E of r.en.slice())if(Math.hypot(E.x-p.x,E.z-p.z)<3.2+E.rad)dmgEnemy(r,p,E,1.6,true,false,12,E.x,1.2,E.z,true)}
  else if(m.k=='R'&&S.cry&&now>=p.cdR){p.cdR=now+17500;p.hp=Math.min(S.hp,p.hp+15);for(const E of r.en)if(Math.hypot(E.x-p.x,E.z-p.z)<6.5)stag(E,1.6)}
  else if(m.k=='H'&&now>=(p.hvT||0)){p.hvT=now+400;const ch=clamp(num(m.ch),0,1),ax=p.x-Math.sin(p.yaw)*2.2,az=p.z-Math.cos(p.yaw)*2.2;
    for(const E of r.en.slice())if(Math.hypot(E.x-ax,E.z-az)<3+E.rad)dmgEnemy(r,p,E,S.heavy*(1+ch)*.5,true,false,10,E.x,.6,E.z,true)}}
function thorn(r,E,p,d){E.hp-=d;E.by=p;if(E.hp<=0)killE(r,E,p,0,0,0,0)}
function sendProg(r,p){r.send(p,{t:'prog',sk:p.sk,pk:p.pk,sp:p.sp,draft:p.draft,picked:p.picked,S:p.S})}
function onBuy(r,p,m){
  if(r.D.phase!='camp')return;
  if(m.k=='sk'){const s=SKILLS.find(q=>q.id==m.id);if(!s||p.sk[s.id])return;const br=SKILLS.filter(q=>q.b==s.b),i=br.indexOf(s);if(i>0&&!p.sk[br[i-1].id])return;if(p.sp<s.c)return;p.sp-=s.c;p.sk[s.id]=1}
  else if(m.k=='pk'){if(p.picked||!p.draft.includes(m.id))return;p.picked=1;p.pk.push(m.id)}else return;
  const o=p.S.hp;p.S=calc(p.sk,p.pk);p.hp+=p.S.hp-o;sendProg(r,p)}
function onReady(r,p){if(r.D.phase=='camp')p.ready=1}
function endDay(r){
  if(r.day==10){r.D.phase='over';r.phase='end';r.winner='Seferciler';r.endAt=Date.now()+15000;r.bc({t:'victory'});r.sendSB();return}
  r.D.phase='camp';r.D.campLeft=45;const pool=PERKS.map(p=>p.id);
  for(const p of r.players.values()){p.sp+=2;p.draft=[];const c=pool.slice();while(p.draft.length<3)p.draft.push(c.splice((R()*c.length)|0,1)[0]);p.picked=0;p.ready=0;sendProg(r,p)}
  r.bc({t:'camp',sec:45,day:r.day})}
function tick(r,dt){
  const D=r.D,hs=humans(r);if(!hs.length||r.phase=='end')return;
  if(D.phase=='idle'){startDay(r);return}
  if(D.phase=='fight'){
    if(!D.fail&&!alive(r).length){D.fail=1;D.failT=4;r.bc({t:'fx',k:'msg',m:'Herkes düştü! Gün yeniden başlıyor'})}
    if(D.fail){if((D.failT-=dt)<=0)startDay(r);return}
    if(D.boss&&!D.bs){D.bs=1;spawnE(r,'boss',0)}
    if((D.t-=dt)<=0&&D.spawned<D.total&&r.en.length<D.max+(D.boss?1:0)){spawnE(r,pickType(r.day),(R()*4)|0);D.spawned++;D.t=Math.max(1.6,3.4-r.day*.12)}
    for(const E of r.en.slice())stepEnemy(r,E,dt);sepEnemies(r);stepPj(r,dt);
    if(!D.fin&&D.spawned>=D.total&&!r.en.length&&(!D.boss||D.bossDead)){D.fin=1;D.t2=2.6;r.bc({t:'fx',k:'msg',m:D.boss?'ZAFER!':'Gün tamamlandı'})}
    if(D.fin&&(D.t2-=dt)<=0){D.fin=0;endDay(r)}}
  else if(D.phase=='camp'){D.campLeft-=dt;if(D.campLeft<=0||hs.every(p=>p.ready)){r.day++;startDay(r)}}}
const snap=r=>r.D.phase=='fight'?{e:r.en.map(E=>[E.id,r2(E.x),r2(E.z),r2(E.yaw),r2(Math.max(0,E.hp/E.max)),ST.indexOf(E.state),r2(E.t0),r2(E.mvs),E.mi]),j:r.pj.map(p=>[p.id,r2(p.x),r2(p.y),r2(p.z),r2(p.vx),r2(p.vy),r2(p.vz)])}:{};
const sbx=r=>({day:r.day,name:DAYN[r.day-1],left:r.en.length+Math.max(0,(r.D.total||0)-(r.D.spawned||0)),ph:r.D.phase,camp:Math.ceil(r.D.campLeft||0)});
const info=r=>'Gün '+r.day+' · '+DAYN[r.day-1];
module.exports={init,reset,onJoin,tick,snap,sbx,info,hitEnemy,onAbil,onBuy,onReady,stag,thorn};

'use strict';
/* ============================================================
   OYUN MODLARI — yeni mod eklemek için buraya yeni bir anahtar ekle.
   Alanlar: name, desc, teams (0/2), pve, roundTime (sn, 0=süresiz), respawnMs
   Kancalar (hepsi isteğe bağlı): init, reset, onJoin, onKill, onTick, canDamage, scoreOf,
     isOver, winner, onRoundEnd, spawnPoint, respawnFor, botGoal, onHitExtra,
     info (HUD metni), sbExtra (skor mesajına ek veri), snapExtra (anlık görüntüye ek veri)
   Botlar tüm PvP modlarında çalışır: botGoal(room,bot) → {x,z,keep,use} ile hedef verilebilir.
   ============================================================ */
const PVE=require('./pve');
const PI=Math.PI,R=Math.random,r2=v=>Math.round(v*100)/100,TEAMN=['Kırmızı','Mavi'];
const ffaSpawn=(r,p)=>{let best={x:0,z:15},bd=-1;for(let i=0;i<8;i++){const a=R()*PI*2,x=Math.sin(a)*15,z=Math.cos(a)*15;let md=99;
  for(const q of r.players.values())if(q!==p&&!q.dead)md=Math.min(md,Math.hypot(q.x-x,q.z-z));if(md>bd){bd=md;best={x,z}}}return best};
const anyOver=(r,lim)=>{for(const p of r.players.values())if(p.score>=lim)return true;return false};
const CAGE={x:0,z:0},EXIT={x:0,z:-19.5};
const MODES={
arena:{name:'Serbest Arena',desc:'Herkes herkese. Öldür, ölürsen yeniden doğ. İlk 20 öldürmeye ulaşan turu kazanır.',roundTime:600,scoreLimit:20,respawnMs:4000,
  canDamage:()=>true,onKill(r,k){k.score++},scoreOf:p=>p.score,isOver(r){return anyOver(r,this.scoreLimit)},reset(r){for(const p of r.players.values())p.score=0},spawnPoint:ffaSpawn},
tdm:{name:'Takımlı Ölüm Maçı',desc:'Kırmızı ve Mavi takım karşı karşıya. Takım arkadaşına vuramazsın. İlk 30 takım öldürmesine ulaşan kazanır.',teams:2,roundTime:600,scoreLimit:30,respawnMs:4000,
  init(r){r.ts=[0,0]},reset(r){r.ts=[0,0];for(const p of r.players.values())p.score=0},
  canDamage:(r,a,v)=>a.team!==v.team,onKill(r,k){k.score++;r.ts[k.team]++},scoreOf:p=>p.score,
  isOver(r){return r.ts[0]>=this.scoreLimit||r.ts[1]>=this.scoreLimit},
  winner(r){return r.ts[0]==r.ts[1]?'Berabere':r.ts[0]>r.ts[1]?'Kırmızı takım':'Mavi takım'},
  info:r=>'Kırmızı '+r.ts[0]+' – '+r.ts[1]+' Mavi',
  spawnPoint(r,p){const a=(p.team?PI:0)+(R()-.5)*1.4;return{x:Math.sin(a)*16,z:Math.cos(a)*16}}},
princess:{name:'Prenses Kurtarma',desc:'Kurtarıcılar kafesteki prensesi (E basılı tut) çıkıp çıkış kapısına ulaştırır; Muhafızlar engeller ya da prensesi öldürür. Roller her tur değişir, 3 tur kazanan maçı alır.',teams:2,roundTime:150,respawnMs:4000,
  role(r,t){return(r.round+t)%2==0?'res':'gua'},
  resetPr(r){r.pr={x:CAGE.x,z:CAGE.z,hp:200,max:200,st:0,prog:0,lastHit:{}};r.prWin=null},
  init(r){r.rw=[0,0];r.round=0;this.resetPr(r)},
  reset(r){if(r.rw[0]>=3||r.rw[1]>=3){r.rw=[0,0];r.round=0}else r.round++;this.resetPr(r);for(const p of r.players.values()){p.use=0;p.score=0}},
  canDamage:(r,a,v)=>a.team!==v.team,onKill(r,k){k.score++},scoreOf:p=>p.score,
  respawnFor(r,p){return this.role(r,p.team)=='res'?6000:3500},
  spawnPoint(r,p){if(this.role(r,p.team)=='res')return{x:(R()-.5)*10,z:17};const a=R()*PI*2,d=4+R()*4;return{x:Math.sin(a)*d,z:Math.cos(a)*d}},
  isOver:r=>!!r.prWin,
  winner(r){const w=r.prWin||'gua',t=[0,1].find(t=>this.role(r,t)==w);return TEAMN[t]+' ('+(w=='res'?'Kurtarıcılar':'Muhafızlar')+')'},
  onRoundEnd(r){const w=r.prWin||'gua';r.rw[[0,1].find(t=>this.role(r,t)==w)]++},
  info:r=>'Tur '+(r.round+1)+' · '+TEAMN[0]+' '+r.rw[0]+' – '+r.rw[1]+' '+TEAMN[1],
  sbExtra(r){return{roles:[this.role(r,0),this.role(r,1)],rw:r.rw,round:r.round}},
  snapExtra(r){const p=r.pr;return{pr:[r2(p.x),r2(p.z),r2(Math.max(0,p.hp)/p.max),p.st,r2(p.prog)]}},
  botGoal(r,b){const pr=r.pr;if(this.role(r,b.team)=='res')return pr.st==0?{x:CAGE.x,z:CAGE.z,keep:1.5,use:1}:{x:EXIT.x,z:EXIT.z,keep:1};return{x:pr.x,z:pr.z,keep:3.5}},
  onTick(r,dt){
    if(r.phase!='play')return;const pr=r.pr;if(pr.st>=2)return;const res=[...r.players.values()].filter(p=>!p.dead&&this.role(r,p.team)=='res');
    if(pr.st==0){const near=res.some(p=>p.use&&Math.hypot(p.x-CAGE.x,p.z-CAGE.z)<2.8);pr.prog=near?Math.min(1,pr.prog+dt/3):Math.max(0,pr.prog-dt*.5);
      if(pr.prog>=1){pr.st=1;r.bc({t:'fx',k:'msg',m:'Prenses kurtarıldı! Çıkışa ulaştır!'})}}
    else if(pr.st==1){let t=null,bd=1e9;for(const p of res){const d=Math.hypot(p.x-pr.x,p.z-pr.z);if(d<bd){bd=d;t=p}}
      if(t&&bd>2){const dx=t.x-pr.x,dz=t.z-pr.z,d=Math.hypot(dx,dz);pr.x+=dx/d*3.4*dt;pr.z+=dz/d*3.4*dt}
      if(Math.hypot(pr.x-EXIT.x,pr.z-EXIT.z)<2.5){pr.st=3;r.prWin='res'}}
    if(pr.hp<=0&&pr.st<2){pr.st=2;r.prWin='gua';r.bc({t:'fx',k:'msg',m:'Prenses öldürüldü!'})}},
  onHitExtra(r,a,m){
    const pr=r.pr,now=Date.now();if(!pr||pr.st>1||a.dead||r.phase!='play'||this.role(r,a.team)!='gua')return;
    if((pr.lastHit[a.id]||0)+280>now||Math.hypot(pr.x-a.x,pr.z-a.z)>5.5)return;pr.lastHit[a.id]=now;
    const sp=Math.min(40,Math.max(0,+m.sp||0)),dmg=Math.min(60,22*(m.hv?2.2:1)*Math.max(.55,Math.min(1.6,sp/12))*a.S.dmg);pr.hp-=dmg;
    r.bc({t:'ph',hp:r2(Math.max(0,pr.hp)/pr.max),x:+m.x||pr.x,y:+m.y||1.2,z:+m.z||pr.z,dmg:Math.round(dmg)})}},
hill:{name:'Kral Tepesi',desc:'Haritanın ortasındaki bölgede tek başına durarak puan topla (öldürme +1). İlk 60 puan kazanır. Herkes herkese.',roundTime:420,scoreLimit:60,respawnMs:4000,
  init(r){r.holder=0},reset(r){r.holder=0;for(const p of r.players.values()){p.score=0;p.hacc=0}},
  canDamage:()=>true,onKill(r,k){k.score++},scoreOf:p=>p.score,isOver(r){return anyOver(r,this.scoreLimit)},spawnPoint:ffaSpawn,
  onTick(r,dt){if(r.phase!='play')return;const ins=[...r.players.values()].filter(p=>!p.dead&&Math.hypot(p.x,p.z)<4.5);
    if(ins.length==1){const p=ins[0];r.holder=p.id;p.hacc=(p.hacc||0)+dt;while(p.hacc>=1){p.score++;p.hacc--}}else r.holder=0},
  info(r){const h=r.players.get(r.holder);return h?'Tepeyi tutan: '+h.name:'Tepe boş'},snapExtra:r=>({hz:r.holder}),botGoal:()=>({x:0,z:0,keep:1.5})},
sefer:{name:'10 Gün Seferi (PvE)',desc:'Birlikte 10 gün hayatta kal, onuncu günün sonunda Arena Lordu Draco’yu yen. Günler arasında yetenek ve perk seç.',pve:true,roundTime:0,respawnMs:12000,
  init:PVE.init,reset:PVE.reset,onJoin:PVE.onJoin,onTick:PVE.tick,snapExtra:PVE.snap,sbExtra:PVE.sbx,info:PVE.info,
  canDamage:()=>false,scoreOf:p=>p.kills|0,isOver:()=>false,winner:()=>'Seferciler',
  spawnPoint:()=>({x:(R()-.5)*8,z:14+R()*3})}
};
module.exports=MODES;

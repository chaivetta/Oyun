# Kan ve Kum: Kolezyum — Çok Oyunculu (v2)

Node.js + WebSocket sunucusu ve tarayıcıda çalışan 3D istemci (Three.js).
Ana menü → **Çok Oyunculu** → isim → **lobi**: oda listesi, **Oda Kur** (mod + bot sayısı seç) ya da **Hızlı Katıl**.

## Kurulum
Node.js 18+ gerekir.

    npm install
    npm start

Varsayılan adres: `http://SUNUCU_IP:3000`

## Modlar
| Mod | Tür | Açıklama |
|---|---|---|
| `sefer` | PvE co-op | 10 gün birlikte hayatta kal, 10. gün Draco. Günler arası yetenek ağacı + perk seçimi. Oyuncu sayısına göre düşman güçlenir. |
| `arena` | PvP | Serbest Arena: herkes herkese, ilk 20 öldürme. |
| `tdm` | PvP takım | Takımlı Ölüm Maçı: Kırmızı–Mavi, ilk 30 takım öldürmesi. Dost ateşi yok. |
| `princess` | PvP takım | Prenses Kurtarma: Kurtarıcılar kafesteki prensesi (E basılı tut) çıkış kapısına ulaştırır, Muhafızlar engeller ya da prensesi öldürür. Roller her tur değişir, 3 tur kazanan maçı alır. |
| `hill` | PvP | Kral Tepesi: ortadaki bölgede tek başına durarak puan topla, ilk 60. |

**Botlar:** Tüm PvP modlarında kullanılabilir. Oda kurarken sayıyı seç; oda sahibi oyun içinde Esc menüsünden **Bot Ekle / Bot Çıkar** yapabilir. (PvE modunda bot yoktur.)

## Ortam değişkenleri
| Değişken | Varsayılan | Açıklama |
|---|---|---|
| `PORT` | 3000 | Dinlenecek port |
| `MAX_ROOMS` | 24 | En fazla oda sayısı |
| `SCORE_LIMIT` | modun kendi değeri | Skor sınırı olan modlar için geçersiz kıl |
| `ROUND_TIME` | modun kendi değeri | Tur süresi (sn), PvE hariç |

## Yayınlama notları
- VPS: portu aç (`ufw allow 3000`), kalıcı çalıştırmak için `pm2 start server.js`.
- nginx arkasında WebSocket için `Upgrade`/`Connection "upgrade"` başlıkları şart (`proxy_http_version 1.1`). Sayfa `https` ise istemci otomatik `wss://` kullanır.
- Sağlık kontrolü: `/health`. Boş odalar 20 sn sonra silinir.

## Güvenlik / hız sınırı
Saniyede en fazla 300 mesaj işlenir (sayaç **her saniye sıfırlanır**); fazlası düşer, yalnızca 1200+ ile sel yapan bağlantı atılır. İstemci ~30 konum paketi/sn gönderir, bu sınıra takılmaz.
Hasar, can, skor ve düşman yapay zekası **sunucuda** hesaplanır; istemci yalnızca “şu hedefe vurdum” der, sunucu mesafe, 280 ms vuruş aralığı, doğuş koruması, blok ve parry’yi doğrular.

## Yeni mod ekleme
`modes.js` içine yeni bir anahtar ekle (örnekler dosyada). Kancalar: `init, reset, onJoin, onKill, onTick, canDamage, scoreOf, isOver, winner, onRoundEnd, spawnPoint, respawnFor, botGoal, onHitExtra, info, sbExtra, snapExtra`.
Bir moda bot desteği için `botGoal(room,bot)` ile `{x,z,keep,use}` hedefi vermen yeterli. Moda özel görseller için `public/index.html` içindeki `mkModeObjs` ve `mpMsg` bölümlerine bak.

## Dosyalar
- `server.js` — HTTP + WebSocket, lobi, oda yönetimi
- `game.js` — oda, savaş kuralları, botlar
- `modes.js` — mod tanımları
- `pve.js` — 10 günlük sefer (düşman yapay zekası, günler, kamp)
- `data.js` — yetenek/perk/düşman verileri
- `public/index.html` — oyun (tek kişilik kampanya + çok oyunculu)

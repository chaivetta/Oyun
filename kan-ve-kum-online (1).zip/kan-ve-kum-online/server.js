'use strict';
const http=require('http'),fs=require('fs'),path=require('path');
const {WebSocketServer}=require('ws');
const MODES=require('./modes'),PVE=require('./pve'),{Room}=require('./game');
const PORT=+process.env.PORT||3000,PUB=path.join(__dirname,'public'),MAXROOMS=+process.env.MAX_ROOMS||24;
for(const m of Object.values(MODES)){if(process.env.SCORE_LIMIT&&m.scoreLimit)m.scoreLimit=+process.env.SCORE_LIMIT;if(process.env.ROUND_TIME&&m.roundTime&&!m.pve)m.roundTime=+process.env.ROUND_TIME}
const rooms=new Map();let rid=1;
/* ---- statik dosya sunucusu ---- */
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.ico':'image/x-icon','.json':'application/json'};
const srv=http.createServer((req,res)=>{
  let u;try{u=decodeURIComponent(req.url.split('?')[0])}catch(e){res.writeHead(400);return res.end()}
  if(u=='/health'){res.writeHead(200);return res.end('ok rooms='+rooms.size)}
  if(u=='/')u='/index.html';
  const f=path.join(PUB,path.normalize(u));if(!f.startsWith(PUB)){res.writeHead(403);return res.end()}
  fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('404')}res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(d)})});
const wss=new WebSocketServer({server:srv,path:'/ws',maxPayload:2048});
const send=(ws,o)=>{if(ws.readyState===1)ws.send(JSON.stringify(o))};
const modeList=()=>Object.entries(MODES).map(([id,m])=>({id,name:m.name,desc:m.desc,pve:!!m.pve,teams:m.teams||0}));
const roomList=()=>[...rooms.values()].map(r=>{const h=r.humans().length;return{id:r.id,name:r.name,mode:r.modeId,mn:r.mode.name,n:h,b:r.players.size-h,max:r.max,ph:r.phase}});
const sendLobby=ws=>send(ws,{t:'lobby',modes:modeList(),rooms:roomList()});
function enter(ws,room){
  if(room.humans().length>=room.max){send(ws,{t:'err',m:'Oda dolu'});return}
  if(room.players.size>=room.max)room.delBot();
  ws.room=room;ws.p=room.join(ws,ws.name);console.log('+',ws.p.name,'→',room.name)}
function create(ws,m){
  const mode=MODES[m.mode];if(!mode){send(ws,{t:'err',m:'Geçersiz mod'});return}
  if(rooms.size>=MAXROOMS){send(ws,{t:'err',m:'Çok fazla oda var'});return}
  const id=rid++,rn=String(m.rname||'').replace(/[\u0000-\u001f<>&"'`]/g,'').trim().slice(0,24)||(mode.name+' #'+id);
  const r=new Room(id,rn,m.mode,m.bots,ws);rooms.set(id,r);enter(ws,r)}
wss.on('connection',ws=>{
  ws.alive=true;ws.cnt=0;ws.on('pong',()=>ws.alive=true);
  ws.on('message',raw=>{
    if(++ws.cnt>300){if(ws.cnt>1200)ws.terminate();return}   // saniyede en fazla 300 mesaj işlenir; sayaç her saniye sıfırlanır
    let m;try{m=JSON.parse(raw)}catch(e){return}if(!m||typeof m!='object')return;
    if(m.t=='hello'){ws.name=String(m.name||'').replace(/[\u0000-\u001f<>&"'`]/g,'').trim().slice(0,16)||'Gladyatör';return sendLobby(ws)}
    if(!ws.name)return;
    if(!ws.p){
      if(m.t=='rooms')sendLobby(ws);else if(m.t=='create')create(ws,m);
      else if(m.t=='enter'){const r=rooms.get(m.room|0);if(r)enter(ws,r);else send(ws,{t:'err',m:'Oda bulunamadı'})}
      else if(m.t=='quick'){let best=null;for(const r of rooms.values())if(!r.mode.pve&&r.phase=='play'&&r.humans().length<r.max&&(!best||r.humans().length>best.humans().length))best=r;
        if(best)enter(ws,best);else create(ws,{mode:'arena',bots:2})}
      return}
    const p=ws.p,r=ws.room;
    switch(m.t){
      case's':r.onState(p,m);break;
      case'hit':r.onHit(p,m);break;
      case'abil':if(r.mode.pve)PVE.onAbil(r,p,m);break;
      case'buy':if(r.mode.pve)PVE.onBuy(r,p,m);break;
      case'ready':if(r.mode.pve)PVE.onReady(r,p);break;
      case'bot':if(r.owner===ws&&!r.mode.pve){if(m.op=='add'){if(r.players.size<r.max){r.botTarget=Math.min(8,r.botTarget+1);r.addBot()}}else if(r.botTarget>0){r.botTarget--;r.delBot()}}break}});
  ws.on('close',()=>{const r=ws.room,p=ws.p;if(!r||!p)return;r.leave(p);ws.p=null;if(r.owner===ws){const h=r.humans()[0];r.owner=h?h.ws:null;if(h)r.send(h,{t:'owner'})}console.log('-',p.name)});
  ws.on('error',()=>{});
});
setInterval(()=>{for(const ws of wss.clients)ws.cnt=0},1000);   // hız sınırı sayacı sıfırlama (düzeltme)
setInterval(()=>{const now=Date.now();
  for(const r of rooms.values()){r.tick();if(!r.humans().length&&r.emptySince&&now-r.emptySince>20000)rooms.delete(r.id)}},50);
setInterval(()=>{for(const ws of wss.clients)if(ws.name&&!ws.p)sendLobby(ws)},2000);
setInterval(()=>{for(const ws of wss.clients){if(!ws.alive)return ws.terminate();ws.alive=false;ws.ping()}},20000);
process.on('uncaughtException',e=>console.error('hata:',e));
srv.listen(PORT,'0.0.0.0',()=>console.log('Kan ve Kum sunucusu hazır → http://localhost:'+PORT+'  (modlar: '+Object.keys(MODES).join(', ')+')'));

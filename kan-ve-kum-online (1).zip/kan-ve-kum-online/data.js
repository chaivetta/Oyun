'use strict';
/* Yetenek, perk ve düşman verileri. Etkiler deklaratif: [alan, işlem, değer] */
const SKILLS=[
{b:'A',id:'a1',n:'Keskin Çelik',d:'+15% hasar',c:1,fx:[['dmg','*',1.15]]},
{b:'A',id:'a2',n:'Hızlı El',d:'+18% saldırı hızı',c:1,fx:[['aspd','*',1.18]]},
{b:'A',id:'a3',n:'Ölümcül Nokta',d:'+14% kritik şansı',c:2,fx:[['crit','+',.14]]},
{b:'A',id:'a4',n:'Kasırga [E]',d:'360° döner kesik, çevreyi biçer',c:2,fx:[['whirl','=',1]]},
{b:'B',id:'b1',n:'Kalın Deri',d:'+35 maksimum can',c:1,fx:[['hp','+',35]]},
{b:'B',id:'b2',n:'Çelik Duruş',d:'Blok %88’e çıkar, stamina az yer',c:1,fx:[['blk','=',.88],['blkCost','*',.6]]},
{b:'B',id:'b3',n:'Usta Parry',d:'Parry süresi uzar, başarıda +8 can',c:2,fx:[['parry','+',.12],['parryHeal','=',8]]},
{b:'B',id:'b4',n:'Demir İrade',d:'Ölümcül darbede 1 kez ayakta kal',c:2,fx:[['iron','=',1]]},
{b:'C',id:'c1',n:'Çevik Adım',d:'+10% hareket hızı',c:1,fx:[['spd','*',1.1]]},
{b:'C',id:'c2',n:'Kan Susuzluğu',d:'Öldürünce +7 can',c:1,fx:[['killHeal','+',7]]},
{b:'C',id:'c3',n:'Nefes Ustası',d:'+35% stamina yenilenmesi',c:2,fx:[['streg','*',1.35]]},
{b:'C',id:'c4',n:'Savaş Narası [R]',d:'Yakındakileri sersemlet, can yenile',c:2,fx:[['cry','=',1]]}];
const PERKS=[
{id:'vamp',n:'Vampir Kan',d:'Vuruş hasarının %6’sı kadar can çalarsın',fx:[['vamp','+',.06]]},
{id:'thorn',n:'Dikenli Zırh',d:'Sana vuran düşman 18 hasar yer',fx:[['thorn','+',18]]},
{id:'frenzy',n:'Kan Ateşi',d:'Öldürünce 4 sn %30 daha çok hasar',fx:[['frenzy','=',1]]},
{id:'heavy',n:'Ağır Eller',d:'Ağır vuruş +60% hasar',fx:[['heavy','*',1.6]]},
{id:'bull',n:'Boğa Gücü',d:'+25 maksimum can',fx:[['hp','+',25]]},
{id:'bleed',n:'Kanama',d:'Vuruşlar 3 sn’de ek 20 hasar kanatır',fx:[['bleed','+',20]]},
{id:'wrist',n:'Sağlam Bilek',d:'Blok stamina maliyeti yarıya iner',fx:[['blkCost','*',.5]]},
{id:'shadow',n:'Gölge Adım',d:'Yuvarlanma daha uzun dokunulmaz ve ucuz',fx:[['roll','+',.2],['rollCost','+',-10]]},
{id:'giant',n:'Dev Avcısı',d:'Brute ve Boss’a +30% hasar',fx:[['giant','=',1.3]]},
{id:'luck',n:'Kolezyum Şansı',d:'+10% kritik, kritik daha güçlü',fx:[['crit','+',.1],['critM','+',.5]]}];
const baseStats=()=>({hp:100,st:100,dmg:1,aspd:1,crit:.06,critM:2,blk:.7,blkCost:1,parry:.22,parryHeal:0,iron:0,spd:1,killHeal:0,streg:1,whirl:0,cry:0,vamp:0,thorn:0,frenzy:0,heavy:1,bleed:0,roll:.35,rollCost:25,giant:1});
function calc(sk,pk){const S=baseStats(),ap=fx=>{for(const[k,o,v]of fx){if(o=='*')S[k]*=v;else if(o=='+')S[k]+=v;else S[k]=v}};
for(const s of SKILLS)if(sk[s.id])ap(s.fx);for(const id of pk){const p=PERKS.find(q=>q.id==id);if(p)ap(p.fx)}return S}
const defs=()=>({skills:SKILLS.map(s=>({b:s.b,id:s.id,n:s.n,d:s.d,c:s.c})),perks:PERKS.map(p=>({id:p.id,n:p.n,d:p.d}))});
const ED={
grunt:{n:'Murmillo',hp:70,spd:2.7,dmg:14,sc:1,rad:.5,shield:1,mv:[{k:'m',wd:.55,rec:.7,reach:2.2,dm:1}]},
fast:{n:'Trakyalı',hp:46,spd:4.3,dmg:9,sc:.92,rad:.45,mv:[{k:'m',wd:.32,rec:.45,reach:2,dm:1,dbl:1}]},
brute:{n:'Secutor',hp:200,spd:1.8,dmg:30,sc:1.3,rad:.7,big:1,mv:[{k:'m',wd:.95,rec:1.1,reach:2.8,dm:1},{k:'s',wd:1.1,rec:1.3,reach:3.4,dm:1.2,R:4}]},
thrower:{n:'Mızrakçı',hp:50,spd:2.9,dmg:17,sc:1,rad:.5,mv:[{k:'t',wd:.8,rec:1,reach:0,dm:1},{k:'m',wd:.6,rec:.8,reach:2.2,dm:1}]},
boss:{n:'Draco',hp:1500,spd:2.4,dmg:36,sc:1.9,rad:1,big:1,boss:1,mv:[{k:'m',wd:.8,rec:.9,reach:3.6,dm:1},{k:'s',wd:1,rec:1.1,reach:4.5,dm:1.1,R:7},{k:'c',wd:.9,rec:1.2,reach:0,dm:1.3}]}};
module.exports={SKILLS,PERKS,baseStats,calc,defs,ED};
